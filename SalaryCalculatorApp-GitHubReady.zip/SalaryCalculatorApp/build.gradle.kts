plugins {
    id("com.android.application") version "8.6.0" apply false
}
